﻿using System;
namespace Entidades
{
    public class Tbl_Empleado
    {
        private bool estadoActividad;
        private String username;
        private String password;
        private String primerNombre;
        private String segundoNombre;
        private String primerApellido;
        private String segundoApellido;
        private DateTime fAgregado;
        private DateTime fEditado;
        private DateTime fEliminado;
        private DateTime fNac;
        private String telefono;
        private bool sexo;
        private String emailPersonal;
        private String emailCorporativo;
        private DateTime fIngreso;
        private int estado;
        private String direccion;
        private String observacion;

        public Tbl_Empleado()
        {
        }

        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string PrimerNombre { get => primerNombre; set => primerNombre = value; }
        public string SegundoNombre { get => segundoNombre; set => segundoNombre = value; }
        public string PrimerApellido { get => primerApellido; set => primerApellido = value; }
        public string SegundoApellido { get => segundoApellido; set => segundoApellido = value; }
        public DateTime FAgregado { get => fAgregado; set => fAgregado = value; }
        public DateTime FEditado { get => fEditado; set => fEditado = value; }
        public DateTime FEliminado { get => fEliminado; set => fEliminado = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public DateTime FNac { get => fNac; set => fNac = value; }
        public bool Sexo { get => sexo; set => sexo = value; }
        public string EmailPersonal { get => emailPersonal; set => emailPersonal = value; }
        public string EmailCorporativo { get => emailCorporativo; set => emailCorporativo = value; }
        public DateTime FIngreso { get => fIngreso; set => fIngreso = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public string Observacion { get => observacion; set => observacion = value; }
        public int Estado { get => estado; set => estado = value; }
        public bool EstadoActividad { get => estadoActividad; set => estadoActividad = value; }
    }
}
