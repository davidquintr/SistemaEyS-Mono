﻿using System;
namespace Entidades
{
    public class Tbl_EmpCar
    {
        private bool estado;
        private int idEmpleado;
        private int idCargo;
        public Tbl_EmpCar()
        {
        }

        public bool Estado { get => estado; set => estado = value; }
        public int IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
        public int IdCargo { get => idCargo; set => idCargo = value; }
    }
}
