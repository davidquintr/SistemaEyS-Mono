﻿using System;
namespace Entidades
{
    public class Tbl_RegistroAsistencia
    {
        private DateTime fechaReg;
        private DateTime horaEntrada;
        private DateTime horaSalida;

        public Tbl_RegistroAsistencia()
        {
        }

        public DateTime FechaReg { get => fechaReg; set => fechaReg = value; }
        public DateTime HoraEntrada { get => horaEntrada; set => horaEntrada = value; }
        public DateTime HoraSalida { get => horaSalida; set => horaSalida = value; }
    }
}
