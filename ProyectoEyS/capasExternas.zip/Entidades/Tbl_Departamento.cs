﻿using System;
namespace Entidades
{
    public class Tbl_Departamento
    {
        private String nombre;
        private String ext;
        private String email;
        private bool estado;
        private String descripcion;
        private DateTime horaEntrada;
        private DateTime horaSalida;
        
        public Tbl_Departamento(){


        }

        public string Nombre { get => nombre; set => nombre = value; }
        public string Ext { get => ext; set => ext = value; }
        public string Email { get => email; set => email = value; }
        public bool Estado { get => estado; set => estado = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public DateTime HoraEntrada { get => horaEntrada; set => horaEntrada = value; }
        public DateTime HoraSalida { get => horaSalida; set => horaSalida = value; }
    }
}
