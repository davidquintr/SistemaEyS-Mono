﻿using System;
namespace Entidades
{
    public class Tbl_User
    {
        private String nombreUser;
        private String pwd;
        private String nombres;
        private String apellidos;
        private String email;
        private String pwd_temp;
        private bool estado;

        public Tbl_User()
        {
        }

        public string NombreUser { get => nombreUser; set => nombreUser = value; }
        public string Pwd { get => pwd; set => pwd = value; }
        public string Nombres { get => nombres; set => nombres = value; }
        public string Apellidos { get => apellidos; set => apellidos = value; }
        public string Email { get => email; set => email = value; }
        public string Pwd_temp { get => pwd_temp; set => pwd_temp = value; }
        public bool Estado { get => estado; set => estado = value; }
    }
}
