﻿using System;
namespace Entidades
{
    public class Tbl_Cargo
    {
        private int idCargo;
        private String nombre;
        private String descripcion;
        private bool estado;
        private int admin;
        public Tbl_Cargo()
        {
        }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
        public bool Estado { get => estado; set => estado = value; }
        public int Admin { get => admin; set => admin = value; }
        public int IdCargo { get => idCargo; set => idCargo = value; }
    }
}
