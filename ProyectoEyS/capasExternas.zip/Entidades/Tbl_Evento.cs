﻿using System;
namespace Entidades
{
    public class Tbl_Evento
    {
        private DateTime fechaInicio;
        private DateTime fechaFin;
        private int estado;
        private String razon;
        private String descripcion; 
        public Tbl_Evento()
        {
        }

        public DateTime FechaInicio { get => fechaInicio; set => fechaInicio = value; }
        public DateTime FechaFin { get => fechaFin; set => fechaFin = value; }
        public int Estado { get => estado; set => estado = value; }
        public string Razon { get => razon; set => razon = value; }
        public string Descripcion { get => descripcion; set => descripcion = value; }
    }
}
