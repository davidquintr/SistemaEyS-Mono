﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Entidades;

namespace Negocio
{
    internal class Ng_creacionDatos
    {
        public Tbl_Departamento CargarDepartamento(string nombre, string ext, string email, bool estado, string descripcion, DateTime horaEntrada, DateTime horaSalida) {
            Tbl_Departamento departamento = new Tbl_Departamento();

            departamento.Nombre = nombre;
            departamento.Ext = ext;
            departamento.Email = email;
            departamento.Estado = estado;
            departamento.Descripcion = descripcion;
            departamento.HoraEntrada = horaEntrada;
            departamento.HoraSalida = horaSalida;

            return departamento;
        }

        public Tbl_Cargo CargarCargo(string nombre, string descripcion, bool estado, int admin) {
            Tbl_Cargo cargo = new Tbl_Cargo();

            cargo.Nombre = nombre;
            cargo.Descripcion = descripcion;
            cargo.Estado = estado;
            cargo.Admin = admin;

            return cargo;
        }

        public Tbl_EmpCar CargarEmpCar(bool estado, int idEmpleado, int idCargo) { 
            Tbl_EmpCar empCar = new Tbl_EmpCar();

            empCar.Estado = estado;
            empCar.IdEmpleado = idEmpleado;
            empCar.IdCargo = idCargo;

            return empCar;
        }

        public Tbl_Empleado CargarEmpleado(bool estadoActividad, string username, string password, string primerNombre, string segundoNombre, string primerApellido, string segundoApellido, DateTime fAgregado, DateTime fEditado, DateTime fEliminado, DateTime fNac, string telefono, bool sexo ,string emailPersonal, string emailCorporativo, DateTime fIngreso, int estado ,string direccion, string observacion) {

            Tbl_Empleado empleado = new Tbl_Empleado();
            empleado.EstadoActividad = estadoActividad;
            empleado.Username = username;
            empleado.Password = password;
            empleado.PrimerNombre = primerNombre;
            empleado.SegundoNombre = segundoNombre;
            empleado.PrimerApellido = primerApellido;
            empleado.SegundoApellido = segundoApellido;
            empleado.FAgregado = fAgregado;
            empleado.FEditado = fEditado;
            empleado.FEliminado = fEliminado;
            empleado.FNac = fNac;
            empleado.Telefono = telefono;
            empleado.Sexo = sexo;
            empleado.EmailPersonal = emailPersonal;
            empleado.EmailCorporativo = emailCorporativo;
            empleado.FIngreso = fIngreso;
            empleado.Estado = estado;
            empleado.Direccion = direccion;
            empleado.Observacion = observacion;

            return empleado;
        }

    }
}
