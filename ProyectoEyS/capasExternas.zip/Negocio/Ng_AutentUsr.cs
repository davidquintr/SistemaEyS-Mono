﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Entidades;


namespace Negocio
{    
    internal class AutenticacionUsuario{

        private List<Tbl_Empleado> empleados;
        private List<Tbl_Cargo> cargos;
        private List<Tbl_EmpCar> empCarg;

        public AutenticacionUsuario(List<Tbl_Empleado> empleados, List<Tbl_EmpCar> empCarg, List<Tbl_Cargo> cargos){
            this.empleados = empleados;
            this.cargos = cargos;
            this.empCarg = empCarg;
        }

        public int ComprobarUsuario(String user, String pass) {

            for (int i = 0; i < empleados.Count(); i++){

                if (empleados[i].Username == user) {
                    if (empleados[i].Password == pass) {
                        return i;
                    }
                }
            }
            return -1;
        }

        public bool comprobarAdmin(int idCargo) {
            if (cargos[idCargo].Admin == 1) {
                return true;
            }
            return false;
        }

        public int comprobarCargo(int idUsuario) { // Retorna el ID del cargo donde se encuentra el usuario

            for (int i = 0; i < empCarg.Count(); i++) {
                if (empCarg[i].IdEmpleado == idUsuario) {
                    return empCarg[i].IdCargo;
                }
            }
            return -1;
        }
    }
}
