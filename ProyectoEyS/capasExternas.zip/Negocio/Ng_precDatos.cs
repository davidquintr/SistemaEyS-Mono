﻿using System;
namespace ProyectoEyS.Negocio
{
    public class Ng_precDatos
    {
        public Ng_precDatos()
        {
        }
    }
}
